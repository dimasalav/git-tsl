<footer>
     <section class="footer">
           <div class="container">
                 <div class="row">
                     <div class="col-md-3 col-6">
                          <h4>Информация</h4>
                          <ul class="list-unstyled">
                            <li><a href="{{route('main')}}">Главная</a></li>
                            <li><a href="{{route('about')}}">О магазине</a></li>
                            <li><a href="{{route('calc')}}">Оплата и доставка</a></li>
                            <li><a href="{{route('about')}}">Контакты</a></li>
                          </ul>
                     </div>

                     <div class="col-md-3 col-6">
                        <h4>Время работы</h4>
                        <ul class="list-unstyled">
                          <li>г. Москва, ул. Пушкина, 1</li>
                          <li>пн-вс: 9:00 - 18:00</li>
                          <li>без ререрыва</li>
                      </ul>
                    </div>

                    <div class="col-md-3 col-6">
                      <h4>Контакты</h4>
                      <ul class="list-unstyled">
                        <li><a href="tel:5551234567">495 123-45-67</a></li>
                        <li><a href="tel:5551234568">495 123-45-68</a></li>
                        <li><a href="tel:5551234569">495 123-45-69</a></li>
                        
                      </ul>
                    </div>
                    <div class="col-md-3 col-6">
                      <h4>Мы в сети</h4>
                      <div class="footer-icons">
                          <!--<a href="#"><i class="bi bi-facebook"></i></a>-->
                          <a href="{{route('about')}}"><i class="fa-brands fa-vk"></i></a>
                          <a href="{{route('about')}}"><i class="bi bi-youtube"></i></a>
                          <!--<a href="#"><i class="bi bi-instagram"></i></a>-->
                          <a href="{{route('about')}}"><i class="fa-brands fa-telegram"></i></a>
                          <a href="{{route('about')}}"><i class="fa-brands fa-square-whatsapp"></i></a>
                      </div>
                    </div>
                 </div>
           </div>
     </section>
</footer>