
<?php $__env->startSection('title-block'); ?>
	Регистрация
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body-class'); ?>
d-flex flex-column min-vh-100
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!----------Форма Регистрации----------------------------------------------------->
     <div class="container flex-grow-1">
        
         <div class="input-reg my-4"> 
         		<h3 class="mb-4">Регистрация</h3>
                    <form action="<?php echo e(route('user.registration')); ?>" method="post">
                    	<?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="name" class="form-label">ФИО</label>  
                                <input type="text" class="form-control" id="name" name="name" placeholder="Введите свое полное имя">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="alert alert-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>  
                            <div class="mb-3"> 
                                <label for="login" class="form-label">Логин</label>  
                                <input type="text" class="form-control" id="login" aria-describedby="loginHelpBlock" name="login" placeholder="Введите свой логин">
                                <div id="loginHelpBlock" class="form-text">Ваш логин должен состоять из не менее 4 символов.</div>
                                <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="alert alert-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>  
                            <div class="mb-3"> 
                                <label for="email" class="form-label">Почта</label>  
                                <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email" placeholder="Введите адрес своей почты">
                                <div id="emailHelp" class="form-text">Мы никогда никому не передадим вашу электронную почту.</div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="alert alert-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--<div class="mb-3">
                                <label for="inputImg" class="form-label">Изображение профиля</label>  
                                <input type="file"  id="inputIMg" name="avatar">
                                
                            </div>-->
                            <div class="mb-3">
                                <label for="password" class="form-label">Пароль</label>  
                                <input type="password" id="password" class="form-control" aria-describedby="passwordHelpBlock" name="password" placeholder="Введите пароль">
                                <div id="passwordHelbBlock" class="form-text">Ваш пароль должен состоять из 4-20 символов.</div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="alert alert-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>  
                            <div class="mt-3 mb-4">
                                <label for="passwordc_confirm" class="form-label">Потверждение пароля</label>  
                                <input type="password" id="password_confirm" class="form-control" name="password_confirmation" placeholder="Подтвердите пароль">
                            </div>    
                                <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                                <p class="form-text mb-5">
                                    У вас уже есть аккаунт?-<a href="<?php echo e(route('user.login')); ?>">Авторизируйтесь</a>
                                </p>                                                           

                    </form>
            </div>
     </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\tsl\resources\views/registration.blade.php ENDPATH**/ ?>