
<?php $__env->startSection('title-block','Обратная связь'); ?>
<?php $__env->startSection('body-class','d-flex flex-column min-vh-100'); ?>
<?php $__env->startSection('content'); ?>
<div class="container flex-grow-1">
   	<div class="row mb-4">
   	   		<div class="col-12">
   			<h2 class="text-center">Обратная связь</h2>
   			<?php if(session('status')): ?>	
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
			<?php endif; ?>
   		</div>		
  	</div>
  	<div class="row">	
   		<div class="col-12 col-md-6 mb-5">
   			<h5 class=" mb-3">Отзывы  о сайте</h5>

   			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<div class="alert alert-info">
        		<h5><?php echo e($post->subject); ?></h5>
        		<p><small><?php echo e($post->created_at); ?></small></p>
        		<a class="link-primary" href="<?php echo e(route('post.show', $post->id)); ?>">Детальнее</a>
    		</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   		</div>


   		<div class="col-12 col-md-6 mb-5">
   			<div class="card">
   				<div class="card-body">
   				<h5 class="text-center mb-3">Здесь вы сможете оставить свой отзыв</h5>
   				<form action="<?php echo e(route('post.store')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<div class="form-group mb-3">
					<label for="name" class="required">Введите имя</label>
					<input type="text" name="name" placeholder="Введите имя" id="name" class="form-control">
					<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						  <div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group mb-3">
					<label for="email" class="required">Email</label>
					<input type="text" name="email" placeholder="Введите email" id="email" class="form-control">
					<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						  <div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="form-group mb-3">
					<label for="subject" class="required">Тема сообщения</label>
					<input type="text" name="subject" placeholder="Тема сообщения" id="subject" class="form-control">
					<?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						  <div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group mb-3">
					<label class="required" for="message">Сообщение</label>
					<textarea name="message" id="message" cols="" rows="5" class="form-control"></textarea>
					<?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						  <div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<button type="submit" class="btn btn-primary mt-3 d-block w-25 mx-auto">Отправить</button>
				</form>
				</div>
			</div>
   		</div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\tsl\resources\views/post/index.blade.php ENDPATH**/ ?>