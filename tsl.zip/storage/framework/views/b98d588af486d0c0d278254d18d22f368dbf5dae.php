
<?php $__env->startSection('title-block','Редактирование'); ?>
<?php $__env->startSection('body-class','d-flex flex-column min-vh-100'); ?>
<?php $__env->startSection('content'); ?>
<!--------Форма Авторизации----------------------------------------------------->
<div class="container flex-grow-1">
    <div class="row">
        <div class="col-12 col-md-6 offset-md-3 mb-5 mt-4">
            <div class="card">
                <div class="card-body">
                <h5 class="text-center mb-3">Здесь вы сможете отредактировать отзыв</h5>
                <form action="<?php echo e(route('post.update',$post->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="form-group mb-3">
                    <label for="name" class="required">Введите имя</label>
                    <input type="text" name="name" placeholder="Введите имя" id="name" class="form-control" value="<?php echo e($post->name); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mb-3">
                    <label for="email" class="required">Email</label>
                    <input type="text" name="email" placeholder="Введите email" id="email" class="form-control" value="<?php echo e($post->email); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group mb-3">
                    <label for="subject" class="required">Тема сообщения</label>
                    <input type="text" name="subject" placeholder="Тема сообщения" id="subject" class="form-control" value="<?php echo e($post->subject); ?>">
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mb-3">
                    <label class="required" for="message">Сообщение</label>
                    <textarea name="message" id="message" cols="" rows="5" class="form-control"><?php echo e($post->message); ?></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary mt-3 d-block w-25 mx-auto">Обновить</button>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\tsl\resources\views/post/edit.blade.php ENDPATH**/ ?>