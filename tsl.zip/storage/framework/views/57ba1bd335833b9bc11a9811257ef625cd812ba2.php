
<?php $__env->startSection('title-block'); ?><?php echo e($post->subject); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('body-class','d-flex flex-column min-vh-100'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container flex-grow-1">
		<div class="row">
			<div class="col-16">
			<?php if(session('status')): ?>	
					<div class="alert alert-success">
						<?php echo e(session('status')); ?>

					</div>
			<?php endif; ?>
			<h4><?php echo e($post->subject); ?></h4>
				<div class="alert alert-info">
			
					<p><?php echo e($post->message); ?></p>
					<p><?php echo e($post->name); ?>-<?php echo e($post->email); ?></p>
					<p><small><?php echo e($post->created_at); ?></small></p>	
					<a class="link-primary" href="<?php echo e(route('post.edit',$post->id)); ?>">Редактировать</a>&nbsp&nbsp
					
					<span class="form__delete">
						<form action="<?php echo e(route('post.destroy',$post->id)); ?>" method="post">
						<?php echo csrf_field(); ?>
						<?php echo method_field('delete'); ?>
						<button  type="submit"><a class="link-danger">Удалить</a></button>
						</form>		
					</span>
				</div>
			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\tsl\resources\views/post/show.blade.php ENDPATH**/ ?>